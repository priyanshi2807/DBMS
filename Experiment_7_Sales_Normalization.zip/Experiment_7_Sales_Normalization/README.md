# Experiment 7: Sales Normalization

Files included:
- `Exp_7.md`: complete lab record with theory and normalization steps.
- `sales_normalization.sql`: MySQL 8.0 script with sample data and verification queries.

Run with: `mysql -u root -p < sales_normalization.sql`
