-- Experiment 7: Sales Table Normalization (UNF to 3NF and BCNF)
-- MySQL 8.0+
-- This script is self-contained and can be run in MySQL Workbench.
-- It demonstrates functional dependencies, normalization, lossless join,
-- and dependency preservation using a small illustrative sales dataset.

DROP DATABASE IF EXISTS sales_normalization_lab;
CREATE DATABASE sales_normalization_lab;
USE sales_normalization_lab;

-- 1. UNF: repeating product groups are represented as comma-separated values.
-- This table is illustrative only; it is not suitable for relational querying.
CREATE TABLE sales_unf (
    sale_id INT PRIMARY KEY,
    sale_date DATE NOT NULL,
    customer_id INT NOT NULL,
    customer_name VARCHAR(100) NOT NULL,
    customer_city VARCHAR(80) NOT NULL,
    product_ids VARCHAR(200) NOT NULL,
    product_names VARCHAR(300) NOT NULL,
    quantities VARCHAR(100) NOT NULL,
    unit_prices VARCHAR(200) NOT NULL
);

INSERT INTO sales_unf VALUES
(1001,'2026-10-01',501,'Aarav Sharma','Chandigarh','P10,P11','Keyboard,Mouse','1,2','1200.00,500.00'),
(1002,'2026-10-02',502,'Meera Kapoor','Mohali','P10,P12','Keyboard,Monitor','1,1','1200.00,8500.00'),
(1003,'2026-10-03',501,'Aarav Sharma','Chandigarh','P11,P12','Mouse,Monitor','1,1','500.00,8500.00');

SELECT * FROM sales_unf;

-- 2. Convert to 1NF: one row per sale/product line; all values are atomic.
CREATE TABLE sales_1nf (
    sale_id INT NOT NULL,
    sale_date DATE NOT NULL,
    customer_id INT NOT NULL,
    customer_name VARCHAR(100) NOT NULL,
    customer_city VARCHAR(80) NOT NULL,
    product_id VARCHAR(10) NOT NULL,
    product_name VARCHAR(100) NOT NULL,
    quantity INT NOT NULL,
    unit_price DECIMAL(10,2) NOT NULL,
    PRIMARY KEY (sale_id, product_id)
);

INSERT INTO sales_1nf VALUES
(1001,'2026-10-01',501,'Aarav Sharma','Chandigarh','P10','Keyboard',1,1200.00),
(1001,'2026-10-01',501,'Aarav Sharma','Chandigarh','P11','Mouse',2,500.00),
(1002,'2026-10-02',502,'Meera Kapoor','Mohali','P10','Keyboard',1,1200.00),
(1002,'2026-10-02',502,'Meera Kapoor','Mohali','P12','Monitor',1,8500.00),
(1003,'2026-10-03',501,'Aarav Sharma','Chandigarh','P11','Mouse',1,500.00),
(1003,'2026-10-03',501,'Aarav Sharma','Chandigarh','P12','Monitor',1,8500.00);

SELECT * FROM sales_1nf ORDER BY sale_id, product_id;

-- Functional dependencies assumed for this dataset:
-- sale_id -> sale_date, customer_id
-- customer_id -> customer_name, customer_city
-- product_id -> product_name, unit_price
-- (sale_id, product_id) -> quantity
-- Therefore (sale_id, product_id) is a candidate key for the 1NF line table.
-- The example assumes a product's unit price is fixed for this lab dataset.
-- Real systems often store the actual sale-time price on the line item instead.

-- 3. 2NF/3NF decomposition:
-- Sales(sale_id -> sale_date, customer_id)
-- Customers(customer_id -> customer_name, customer_city)
-- Products(product_id -> product_name, unit_price)
-- SaleItems((sale_id, product_id) -> quantity)
CREATE TABLE customers (
    customer_id INT PRIMARY KEY,
    customer_name VARCHAR(100) NOT NULL,
    customer_city VARCHAR(80) NOT NULL
);

CREATE TABLE products (
    product_id VARCHAR(10) PRIMARY KEY,
    product_name VARCHAR(100) NOT NULL,
    unit_price DECIMAL(10,2) NOT NULL CHECK (unit_price >= 0)
);

CREATE TABLE sales (
    sale_id INT PRIMARY KEY,
    sale_date DATE NOT NULL,
    customer_id INT NOT NULL,
    CONSTRAINT fk_sales_customer FOREIGN KEY (customer_id)
        REFERENCES customers(customer_id)
);

CREATE TABLE sale_items (
    sale_id INT NOT NULL,
    product_id VARCHAR(10) NOT NULL,
    quantity INT NOT NULL CHECK (quantity > 0),
    PRIMARY KEY (sale_id, product_id),
    CONSTRAINT fk_items_sale FOREIGN KEY (sale_id) REFERENCES sales(sale_id),
    CONSTRAINT fk_items_product FOREIGN KEY (product_id) REFERENCES products(product_id)
);

INSERT INTO customers VALUES
(501,'Aarav Sharma','Chandigarh'),
(502,'Meera Kapoor','Mohali');

INSERT INTO products VALUES
('P10','Keyboard',1200.00),
('P11','Mouse',500.00),
('P12','Monitor',8500.00);

INSERT INTO sales VALUES
(1001,'2026-10-01',501),
(1002,'2026-10-02',502),
(1003,'2026-10-03',501);

INSERT INTO sale_items VALUES
(1001,'P10',1),(1001,'P11',2),
(1002,'P10',1),(1002,'P12',1),
(1003,'P11',1),(1003,'P12',1);

-- 4. Reconstruct the original atomic 1NF relation from the decomposed tables.
SELECT s.sale_id, s.sale_date, c.customer_id, c.customer_name, c.customer_city,
       p.product_id, p.product_name, si.quantity, p.unit_price
FROM sales s
JOIN customers c ON c.customer_id = s.customer_id
JOIN sale_items si ON si.sale_id = s.sale_id
JOIN products p ON p.product_id = si.product_id
ORDER BY s.sale_id, p.product_id;

-- 5. Lossless-join verification:
-- Compare row counts and both directions of set difference.
-- A zero mismatch count in both directions means the decomposed join
-- reproduces the 1NF relation for this sample dataset.
SELECT
  (SELECT COUNT(*) FROM sales_1nf) AS original_rows,
  (SELECT COUNT(*) FROM (
      SELECT s.sale_id, s.sale_date, c.customer_id, c.customer_name, c.customer_city,
             p.product_id, p.product_name, si.quantity, p.unit_price
      FROM sales s
      JOIN customers c ON c.customer_id = s.customer_id
      JOIN sale_items si ON si.sale_id = s.sale_id
      JOIN products p ON p.product_id = si.product_id
  ) AS reconstructed) AS reconstructed_rows;

-- Rows present in original but absent from reconstruction (expect 0).
SELECT COUNT(*) AS original_not_reconstructed
FROM sales_1nf o
WHERE NOT EXISTS (
    SELECT 1
    FROM sales s
    JOIN customers c ON c.customer_id = s.customer_id
    JOIN sale_items si ON si.sale_id = s.sale_id
    JOIN products p ON p.product_id = si.product_id
    WHERE s.sale_id = o.sale_id
      AND s.sale_date = o.sale_date
      AND c.customer_id = o.customer_id
      AND c.customer_name = o.customer_name
      AND c.customer_city = o.customer_city
      AND p.product_id = o.product_id
      AND p.product_name = o.product_name
      AND si.quantity = o.quantity
      AND p.unit_price = o.unit_price
);

-- Rows present in reconstruction but absent from original (expect 0).
SELECT COUNT(*) AS reconstructed_not_original
FROM (
    SELECT s.sale_id, s.sale_date, c.customer_id, c.customer_name, c.customer_city,
           p.product_id, p.product_name, si.quantity, p.unit_price
    FROM sales s
    JOIN customers c ON c.customer_id = s.customer_id
    JOIN sale_items si ON si.sale_id = s.sale_id
    JOIN products p ON p.product_id = si.product_id
) r
WHERE NOT EXISTS (
    SELECT 1 FROM sales_1nf o
    WHERE o.sale_id = r.sale_id
      AND o.sale_date = r.sale_date
      AND o.customer_id = r.customer_id
      AND o.customer_name = r.customer_name
      AND o.customer_city = r.customer_city
      AND o.product_id = r.product_id
      AND o.product_name = r.product_name
      AND o.quantity = r.quantity
      AND o.unit_price = r.unit_price
);

-- 6. Dependency preservation:
-- Each listed functional dependency can be checked in its owning table.
-- Each query should return zero violating groups.
SELECT customer_id, COUNT(DISTINCT customer_name, customer_city) AS variants
FROM customers GROUP BY customer_id HAVING variants > 1;

SELECT product_id, COUNT(DISTINCT product_name, unit_price) AS variants
FROM products GROUP BY product_id HAVING variants > 1;

SELECT sale_id, COUNT(DISTINCT sale_date, customer_id) AS variants
FROM sales GROUP BY sale_id HAVING variants > 1;

SELECT sale_id, product_id, COUNT(DISTINCT quantity) AS variants
FROM sale_items GROUP BY sale_id, product_id HAVING variants > 1;

-- 7. BCNF discussion and demonstration:
-- The four decomposed relations are in BCNF under the stated FDs:
-- Customers: customer_id is a key.
-- Products: product_id is a key.
-- Sales: sale_id is a key.
-- Sale_Items: (sale_id, product_id) is a key and there are no non-key determinants.
-- Thus every non-trivial FD in each relation has a superkey determinant.
-- Check keys and foreign-key constraints using metadata:
SHOW CREATE TABLE customers;
SHOW CREATE TABLE products;
SHOW CREATE TABLE sales;
SHOW CREATE TABLE sale_items;

-- 8. Optional negative test: duplicate line item should be rejected by the PK.
-- Uncomment to test; MySQL should report duplicate entry for (1001, P10).
-- INSERT INTO sale_items VALUES (1001, 'P10', 9);

-- Final row-count summary
SELECT 'customers' AS table_name, COUNT(*) AS row_count FROM customers
UNION ALL SELECT 'products', COUNT(*) FROM products
UNION ALL SELECT 'sales', COUNT(*) FROM sales
UNION ALL SELECT 'sale_items', COUNT(*) FROM sale_items;
