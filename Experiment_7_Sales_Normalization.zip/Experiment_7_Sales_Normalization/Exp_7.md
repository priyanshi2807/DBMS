# Experiment 7 – Functional Dependencies and Normalization of a Sales Table

## Aim

Given a denormalized Sales table, identify functional dependencies and normalize the relation step-by-step from **UNF to 1NF, 2NF, 3NF and BCNF**. Verify **lossless join** and **dependency preservation** using SQL queries.

## Software Required

- MySQL Server 8.0 or later
- MySQL Workbench or MySQL command-line client

## Files

| File | Description |
|---|---|
| [`sales_normalization.sql`](sales_normalization.sql) | Self-contained SQL script: sample data, normalization, joins and verification queries |
| `README.md` | This experiment record |

## How to Run

```bash
mysql -u root -p < sales_normalization.sql
```

Or open `sales_normalization.sql` in MySQL Workbench and execute the script. The script creates and replaces a database named `sales_normalization_lab`.

> **Note:** The sample assumes that each product has one fixed unit price. In a production sales system, the actual price charged should usually be stored on each sale line because prices may change over time.

---

## 1. Theory

### 1.1 Functional Dependency (FD)

A functional dependency `X → Y` means that each value of attribute set `X` determines exactly one value of attribute set `Y`.

Examples in this experiment:

- `sale_id → sale_date, customer_id`
- `customer_id → customer_name, customer_city`
- `product_id → product_name, unit_price`
- `(sale_id, product_id) → quantity`

### 1.2 Normal Forms

| Normal Form | Main rule | Problem addressed |
|---|---|---|
| UNF | Repeating groups or non-atomic values may exist | Unstructured/repeating data |
| 1NF | Each cell contains one atomic value; no repeating groups | Multi-valued cells |
| 2NF | In 1NF and every non-prime attribute depends on the whole candidate key | Partial dependency |
| 3NF | For every non-trivial FD `X → A`, X is a superkey or A is prime | Transitive dependency |
| BCNF | For every non-trivial FD `X → Y`, X is a superkey | Determinants that are not superkeys |

### 1.3 Why Normalize?

Normalization reduces duplicate data and helps avoid insertion, update and deletion anomalies. It also makes dependencies explicit and improves data integrity.

---

## 2. Initial Denormalized Relation (UNF)

The initial `sales_unf` table stores multiple product IDs, names, quantities and prices in comma-separated strings.

| sale_id | sale_date | customer_id | customer_name | customer_city | product_ids | quantities |
|---:|---|---:|---|---|---|---|
| 1001 | 2026-10-01 | 501 | Aarav Sharma | Chandigarh | P10,P11 | 1,2 |
| 1002 | 2026-10-02 | 502 | Meera Kapoor | Mohali | P10,P12 | 1,1 |
| 1003 | 2026-10-03 | 501 | Aarav Sharma | Chandigarh | P11,P12 | 1,1 |

**Problem:** The product and quantity columns contain repeating groups. Individual products cannot be queried or constrained cleanly.

---

## 3. Functional Dependencies and Candidate Key

The functional dependencies assumed for this sample are:

| Functional Dependency | Meaning |
|---|---|
| `sale_id → sale_date, customer_id` | A sale number determines its date and customer |
| `customer_id → customer_name, customer_city` | A customer ID determines customer details |
| `product_id → product_name, unit_price` | A product ID determines product details and the assumed fixed price |
| `(sale_id, product_id) → quantity` | Within a sale, the product line determines its quantity |

In the atomic line-item relation, the candidate key is **`(sale_id, product_id)`**, because one product appears at most once per sale in this model.

---

## 4. Step-by-Step Normalization

### Step 1: UNF to 1NF

Create one row for each product on each sale. Every attribute now stores one value.

Example:

| sale_id | customer_id | product_id | product_name | quantity |
|---:|---:|---|---|---:|
| 1001 | 501 | P10 | Keyboard | 1 |
| 1001 | 501 | P11 | Mouse | 2 |

The composite key is `(sale_id, product_id)`.

### Step 2: 1NF to 2NF

In the original wide 1NF relation, some attributes depend only on part of the composite key:

- `sale_id → sale_date, customer_id`
- `product_id → product_name, unit_price`

These are partial dependencies. Separate sale-level and product-level facts from the line item. The `sale_items` table keeps only the composite key and `quantity`.

### Step 3: 2NF to 3NF

There is a transitive dependency:

` sale_id → customer_id → customer_name, customer_city `

Customer details depend on `customer_id`, not directly on the sale key. Move those details into `customers`, and reference the customer from `sales`.

### Step 4: 3NF to BCNF

Under the stated functional dependencies, each resulting relation has only determinants that are candidate keys/superkeys:

- `customers(customer_id, customer_name, customer_city)`
- `products(product_id, product_name, unit_price)`
- `sales(sale_id, sale_date, customer_id)`
- `sale_items(sale_id, product_id, quantity)`

Therefore, these relations satisfy BCNF under the assumptions above.

---

## 5. Implementation

The SQL file creates the sample data and the following tables:

- `customers`
- `products`
- `sales`
- `sale_items`

Primary keys enforce uniqueness. Foreign keys ensure each sale refers to an existing customer and each line refers to an existing sale and product. `CHECK` constraints reject negative prices and non-positive quantities.

Run the script to create the tables and insert the sample rows.

---

## 6. Lossless-Join Verification

A decomposition is lossless when joining the decomposed relations reconstructs the original relation without losing rows or creating spurious rows.

The SQL script:

1. Joins `sales`, `customers`, `sale_items` and `products`.
2. Compares the original 1NF row count with the reconstructed row count.
3. Counts original rows missing from the reconstructed result.
4. Counts reconstructed rows missing from the original.

**Expected result:** both mismatch counts are `0`, and the row counts match.

This is an empirical verification for the sample data. The theoretical reason the decomposition is lossless is that each join uses primary-key/foreign-key relationships and the shared key attributes determine the joined relation's relevant facts.

---

## 7. Dependency-Preservation Verification

A decomposition is dependency-preserving if the functional dependencies can be enforced by checking the decomposed relations without needing to join them all back together.

The SQL script runs grouped queries against the owning tables:

- `customers`: check `customer_id → customer_name, customer_city`
- `products`: check `product_id → product_name, unit_price`
- `sales`: check `sale_id → sale_date, customer_id`
- `sale_items`: check `(sale_id, product_id) → quantity`

**Expected result:** each query returns no violating groups. Primary keys directly enforce the uniqueness side of these dependencies; the queries are included as explicit demonstrations.

---

## 8. Expected Observations

- UNF contains repeating, comma-separated groups.
- 1NF stores one product line per row.
- 2NF removes partial dependencies from the composite-key relation.
- 3NF removes the transitive dependency for customer details.
- Under the declared FDs, the decomposed tables satisfy BCNF.
- The reconstruction query returns the six atomic sale lines.
- Lossless-join mismatch counts are zero.
- Dependency-violation queries return zero rows.

Outputs may look slightly different depending on the MySQL client.

---

## 9. Result

The denormalized Sales data was analyzed and normalized from **UNF to 1NF, 2NF, 3NF and BCNF**. Functional dependencies and candidate keys were identified. SQL queries were provided to reconstruct the original atomic relation and verify lossless join and dependency preservation for the sample dataset.

## Viva Questions

1. What is a functional dependency?
2. What is a candidate key?
3. What is the difference between 1NF and 2NF?
4. What is a partial dependency?
5. What is a transitive dependency?
6. How does BCNF differ from 3NF?
7. What is a lossless decomposition?
8. What does dependency preservation mean?
9. Why are primary and foreign keys used in this experiment?
10. Why might a real sales system store unit price on `sale_items` instead of `products`?
